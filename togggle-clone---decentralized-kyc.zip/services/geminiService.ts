import { GoogleGenAI, Type } from "@google/genai";
import { RiskAnalysisResult, RiskLevel } from "../types";

const apiKey = process.env.API_KEY || '';

// Initialize the client
const ai = new GoogleGenAI({ apiKey });

export const analyzeRiskScenario = async (scenario: string): Promise<RiskAnalysisResult> => {
  if (!apiKey) {
    throw new Error("API Key is missing.");
  }

  const systemInstruction = `
    You are an expert Anti-Money Laundering (AML) and Know Your Customer (KYC) compliance officer for a decentralized identity platform.
    Analyze the provided user scenario and determine the risk level.
    Return a structured JSON object.
    
    Risk Logic:
    - High amounts (> $10k) without history -> Medium/High
    - Suspicious locations (Sanctioned countries) -> High
    - Normal behavior -> Low
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: scenario,
      config: {
        systemInstruction,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            riskLevel: { type: Type.STRING, enum: [RiskLevel.LOW, RiskLevel.MEDIUM, RiskLevel.HIGH] },
            score: { type: Type.NUMBER, description: "Risk score from 0 to 100" },
            reasoning: { type: Type.STRING },
            recommendations: { 
              type: Type.ARRAY, 
              items: { type: Type.STRING }
            }
          },
          required: ["riskLevel", "score", "reasoning", "recommendations"]
        }
      }
    });

    const text = response.text;
    if (!text) throw new Error("No response from AI");
    
    return JSON.parse(text) as RiskAnalysisResult;
  } catch (error) {
    console.error("Gemini Analysis Error:", error);
    // Fallback for demo purposes if API fails or quota exceeded
    return {
      riskLevel: RiskLevel.MEDIUM,
      score: 50,
      reasoning: "Unable to connect to AI engine. Defaulting to medium risk for safety.",
      recommendations: ["Perform manual review", "Check API connectivity"]
    };
  }
};
