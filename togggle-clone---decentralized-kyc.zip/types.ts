import React from 'react';

export interface NavItem {
  label: string;
  href: string;
}

export interface Feature {
  title: string;
  description: string;
  icon: React.ComponentType<any>;
}

export enum RiskLevel {
  LOW = 'Low',
  MEDIUM = 'Medium',
  HIGH = 'High'
}

export interface RiskAnalysisResult {
  riskLevel: RiskLevel;
  score: number;
  reasoning: string;
  recommendations: string[];
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
}