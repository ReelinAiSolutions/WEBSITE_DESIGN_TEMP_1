import React from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import Features from './components/Features';
import ComplianceDemo from './components/ComplianceDemo';
import Footer from './components/Footer';

const App: React.FC = () => {
  return (
    <div className="min-h-screen bg-brand-dark text-white selection:bg-brand-primary/30">
      <Header />
      <main>
        <Hero />
        
        {/* Trusted By Section */}
        <div className="py-10 border-y border-white/5 bg-black/20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <p className="text-center text-sm font-semibold text-gray-500 uppercase tracking-widest mb-8">
              Trusted by leading web3 companies
            </p>
            <div className="flex flex-wrap justify-center items-center gap-12 md:gap-20 opacity-50 grayscale hover:grayscale-0 transition-all duration-500">
              {/* Placeholders for logos using simple text for this clone */}
              <span className="text-xl font-bold font-sans">Binance</span>
              <span className="text-xl font-bold font-sans">Coinbase</span>
              <span className="text-xl font-bold font-sans">Polygon</span>
              <span className="text-xl font-bold font-sans">Aave</span>
              <span className="text-xl font-bold font-sans">Metamask</span>
            </div>
          </div>
        </div>

        <Features />
        
        {/* Integration Code Snippet Visual */}
        <section className="py-24 bg-brand-dark relative overflow-hidden">
          <div className="absolute top-0 right-0 w-1/2 h-full bg-brand-primary/5 blur-3xl rounded-full pointer-events-none"></div>
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="lg:grid lg:grid-cols-2 lg:gap-16 items-center">
              <div className="mb-12 lg:mb-0">
                <h2 className="text-3xl md:text-5xl font-bold text-white mb-6">
                  Integrate in <br />
                  <span className="text-brand-primary">under 5 minutes</span>
                </h2>
                <p className="text-gray-400 text-lg mb-8 leading-relaxed">
                   Our SDK is designed for developer happiness. Drop in a few lines of code and start verifying users instantly with full customization control.
                </p>
                <ul className="space-y-4 mb-8">
                  <li className="flex items-center gap-3 text-gray-300">
                    <span className="flex items-center justify-center w-6 h-6 rounded-full bg-brand-primary/20 text-brand-primary text-xs font-bold">1</span>
                    Install the NPM package
                  </li>
                  <li className="flex items-center gap-3 text-gray-300">
                    <span className="flex items-center justify-center w-6 h-6 rounded-full bg-brand-primary/20 text-brand-primary text-xs font-bold">2</span>
                    Initialize with your API key
                  </li>
                  <li className="flex items-center gap-3 text-gray-300">
                    <span className="flex items-center justify-center w-6 h-6 rounded-full bg-brand-primary/20 text-brand-primary text-xs font-bold">3</span>
                    Handle the verification callback
                  </li>
                </ul>
                <a href="#" className="text-brand-primary font-semibold hover:text-brand-primary/80 transition-colors">
                  Read the docs &rarr;
                </a>
              </div>
              
              <div className="relative">
                <div className="absolute -inset-1 bg-gradient-to-r from-brand-primary to-brand-secondary rounded-2xl opacity-20 blur"></div>
                <div className="relative bg-[#0F111A] rounded-2xl border border-white/10 p-6 shadow-2xl overflow-hidden font-mono text-sm">
                  <div className="flex items-center gap-2 mb-4 border-b border-white/5 pb-4">
                    <div className="w-3 h-3 rounded-full bg-red-500/50"></div>
                    <div className="w-3 h-3 rounded-full bg-yellow-500/50"></div>
                    <div className="w-3 h-3 rounded-full bg-green-500/50"></div>
                    <span className="ml-auto text-xs text-gray-500">App.tsx</span>
                  </div>
                  <div className="text-gray-300 overflow-x-auto">
                    <pre><code><span className="text-purple-400">import</span> {"{"} Togggle {"}"} <span className="text-purple-400">from</span> <span className="text-green-400">'@togggle/react'</span>;

<span className="text-purple-400">export default function</span> <span className="text-blue-400">App</span>() {"{"}
  <span className="text-purple-400">return</span> (
    <span className="text-gray-500">&lt;</span><span className="text-brand-primary">Togggle</span> 
      <span className="text-blue-300">apiKey</span>=<span className="text-green-400">"pk_live_..."</span>
      <span className="text-blue-300">onSuccess</span>={"{"}(<span className="text-orange-300">user</span>) <span className="text-purple-400">=&gt;</span> {"{"}
        <span className="text-yellow-200">console</span>.<span className="text-blue-300">log</span>(<span className="text-green-400">'Verified!'</span>, user);
      {"}"}{"}"}
    <span className="text-gray-500">/&gt;</span>
  );
{"}"}</code></pre>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <ComplianceDemo />
        
        {/* CTA Section */}
        <section className="py-24 relative overflow-hidden">
          <div className="absolute inset-0 bg-brand-primary/10"></div>
          <div className="max-w-4xl mx-auto px-4 relative z-10 text-center">
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">Ready to secure your platform?</h2>
            <p className="text-xl text-gray-300 mb-10">
              Join hundreds of companies using Togggle to verify users without compromising privacy.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
               <a href="#demo" className="w-full sm:w-auto px-8 py-4 bg-brand-primary text-white rounded-full font-bold hover:bg-brand-primary/90 transition-all shadow-lg shadow-brand-primary/25">
                 Get Started Free
               </a>
               <button className="w-full sm:w-auto px-8 py-4 bg-transparent border border-white/20 text-white rounded-full font-bold hover:bg-white/10 transition-all">
                 Contact Sales
               </button>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default App;