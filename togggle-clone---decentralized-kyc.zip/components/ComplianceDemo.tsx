import React, { useState } from 'react';
import { analyzeRiskScenario } from '../services/geminiService';
import { RiskAnalysisResult, RiskLevel } from '../types';
import { Loader2, AlertTriangle, ShieldCheck, ShieldAlert, BrainCircuit } from 'lucide-react';

const ComplianceDemo: React.FC = () => {
  const [scenario, setScenario] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<RiskAnalysisResult | null>(null);

  const handleAnalyze = async () => {
    if (!scenario.trim()) return;
    setLoading(true);
    setResult(null);
    
    try {
      const data = await analyzeRiskScenario(scenario);
      setResult(data);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const predefinedScenarios = [
    "A user from Germany wants to deposit 500 EUR via bank transfer.",
    "A newly registered user from North Korea attempts to withdraw $50,000 in crypto immediately.",
    "User with valid ID uploads a blurry selfie that doesn't match ID photo."
  ];

  return (
    <section id="demo" className="py-24 bg-brand-card border-y border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-brand-primary/10 border border-brand-primary/20 mb-6">
              <BrainCircuit className="w-4 h-4 text-brand-primary" />
              <span className="text-xs font-bold text-brand-primary uppercase">Powered by Gemini 2.5</span>
            </div>
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
              AI-Powered Risk Analysis
            </h2>
            <p className="text-gray-400 text-lg mb-8 leading-relaxed">
              Experience our advanced compliance engine. Describe a user action or transaction scenario, and our AI will instantly assess the risk level based on global AML/CFT standards.
            </p>
            
            <div className="space-y-4">
               <p className="text-sm font-medium text-gray-500 uppercase tracking-wider">Try a scenario:</p>
               <div className="flex flex-wrap gap-2">
                 {predefinedScenarios.map((s, i) => (
                   <button 
                    key={i}
                    onClick={() => setScenario(s)}
                    className="text-left text-sm p-3 rounded-lg bg-white/5 hover:bg-white/10 border border-white/5 transition-colors text-gray-300"
                   >
                     "{s.slice(0, 50)}..."
                   </button>
                 ))}
               </div>
            </div>
          </div>

          <div className="glass-card rounded-2xl p-6 md:p-8 border border-white/10 shadow-2xl relative">
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-brand-primary to-brand-secondary rounded-t-2xl"></div>
            
            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-300 mb-2">Transaction / User Scenario</label>
              <textarea
                value={scenario}
                onChange={(e) => setScenario(e.target.value)}
                placeholder="E.g., User A from a high-risk jurisdiction is attempting a large volume transaction without prior history..."
                className="w-full h-32 bg-black/50 border border-white/10 rounded-xl p-4 text-white placeholder-gray-600 focus:outline-none focus:ring-2 focus:ring-brand-primary/50 transition-all resize-none"
              />
            </div>

            <button
              onClick={handleAnalyze}
              disabled={loading || !scenario}
              className={`w-full py-4 rounded-xl font-semibold flex items-center justify-center gap-2 transition-all ${
                loading || !scenario 
                  ? 'bg-white/5 text-gray-500 cursor-not-allowed' 
                  : 'bg-brand-primary hover:bg-brand-primary/90 text-white shadow-lg shadow-brand-primary/25'
              }`}
            >
              {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <ShieldCheck className="w-5 h-5" />}
              {loading ? 'Analyzing Risk...' : 'Analyze Risk'}
            </button>

            {/* Results Display */}
            {result && (
              <div className="mt-8 pt-8 border-t border-white/10 animate-fade-in">
                <div className="flex items-center justify-between mb-4">
                  <span className="text-sm font-medium text-gray-400">Risk Assessment</span>
                  <div className={`px-4 py-1 rounded-full text-sm font-bold flex items-center gap-2
                    ${result.riskLevel === RiskLevel.LOW ? 'bg-green-500/10 text-green-400 border border-green-500/20' : 
                      result.riskLevel === RiskLevel.MEDIUM ? 'bg-yellow-500/10 text-yellow-400 border border-yellow-500/20' : 
                      'bg-red-500/10 text-red-400 border border-red-500/20'}`}>
                    {result.riskLevel === RiskLevel.LOW && <ShieldCheck className="w-4 h-4" />}
                    {result.riskLevel === RiskLevel.MEDIUM && <AlertTriangle className="w-4 h-4" />}
                    {result.riskLevel === RiskLevel.HIGH && <ShieldAlert className="w-4 h-4" />}
                    {result.riskLevel.toUpperCase()} RISK ({result.score}/100)
                  </div>
                </div>
                
                <div className="space-y-4">
                  <div>
                    <h4 className="text-xs uppercase tracking-wide text-gray-500 mb-1">Reasoning</h4>
                    <p className="text-sm text-gray-300 leading-relaxed">{result.reasoning}</p>
                  </div>
                  
                  <div>
                    <h4 className="text-xs uppercase tracking-wide text-gray-500 mb-2">Recommendations</h4>
                    <ul className="space-y-2">
                      {result.recommendations.map((rec, i) => (
                        <li key={i} className="flex items-start gap-2 text-sm text-gray-300">
                          <span className="mt-1 w-1.5 h-1.5 rounded-full bg-brand-primary flex-shrink-0"></span>
                          {rec}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};

export default ComplianceDemo;