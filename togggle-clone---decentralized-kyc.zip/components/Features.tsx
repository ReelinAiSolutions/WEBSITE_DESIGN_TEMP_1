import React from 'react';
import { Lock, Zap, Globe, Fingerprint, RefreshCcw, Database } from 'lucide-react';
import { Feature } from '../types';

const features: Feature[] = [
  {
    title: "Zero-Knowledge Storage",
    description: "We never store sensitive user data. Everything is encrypted and stored on the user's device.",
    icon: Database
  },
  {
    title: "Instant Verification",
    description: "Verify users in seconds using reusable credentials. No more waiting for manual reviews.",
    icon: Zap
  },
  {
    title: "Global Compliance",
    description: "Automated checks against global sanctions, PEP lists, and adverse media across 200+ jurisdictions.",
    icon: Globe
  },
  {
    title: "Biometric Auth",
    description: "Liveness detection and biometric matching ensure the person is who they claim to be.",
    icon: Fingerprint
  },
  {
    title: "Reusable Identity",
    description: "Users verify once and can reuse their status across the entire partner network.",
    icon: RefreshCcw
  },
  {
    title: "Bank-Grade Security",
    description: "AES-256 encryption and decentralized architecture eliminate single points of failure.",
    icon: Lock
  }
];

const Features: React.FC = () => {
  return (
    <section id="features" className="py-24 bg-brand-dark relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-bold text-white mb-6">
            The Future of Identity
          </h2>
          <p className="text-gray-400 max-w-2xl mx-auto text-lg">
            Traditional KYC is broken. We fixed it by removing the central database and putting users in control.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div key={index} className="glass-card p-8 rounded-2xl hover:bg-white/5 transition-colors group cursor-default">
              <div className="w-12 h-12 rounded-lg bg-brand-primary/10 flex items-center justify-center mb-6 group-hover:bg-brand-primary/20 transition-colors">
                <feature.icon className="w-6 h-6 text-brand-primary" />
              </div>
              <h3 className="text-xl font-bold text-white mb-3">{feature.title}</h3>
              <p className="text-gray-400 leading-relaxed">
                {feature.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;