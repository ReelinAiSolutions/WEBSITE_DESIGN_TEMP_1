import React, { useState, useEffect } from 'react';
import { Menu, X, Search, ChevronDown } from 'lucide-react';

const Navbar: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Expertise', hasDropdown: true },
    { name: 'Markets', hasDropdown: true },
    { name: 'Projects', hasDropdown: false },
    { name: 'Careers', hasDropdown: false },
    { name: 'About', hasDropdown: true },
  ];

  return (
    <nav 
      className={`fixed w-full z-50 transition-all duration-300 ${
        isScrolled ? 'bg-white shadow-md py-2' : 'bg-transparent py-4'
      }`}
    >
      <div className="container mx-auto px-6 flex justify-between items-center">
        {/* Logo */}
        <div className="flex items-center">
          <a href="#" className="flex items-center gap-2">
            {/* Simple SVG Logo approximation */}
            <div className={`w-10 h-10 ${isScrolled ? 'bg-mccarthy-red' : 'bg-mccarthy-red'} flex items-center justify-center text-white font-bold font-header text-xl`}>
              M
            </div>
            <span className={`font-header font-bold text-2xl tracking-tighter uppercase ${isScrolled ? 'text-mccarthy-dark' : 'text-white'}`}>
              McCarthy
            </span>
          </a>
        </div>

        {/* Desktop Nav */}
        <div className="hidden lg:flex items-center space-x-8">
          {navLinks.map((link) => (
            <div key={link.name} className="group relative cursor-pointer">
              <span className={`font-bold uppercase text-sm tracking-wide flex items-center gap-1 ${isScrolled ? 'text-gray-800 hover:text-mccarthy-red' : 'text-white hover:text-gray-200'}`}>
                {link.name}
                {link.hasDropdown && <ChevronDown size={14} />}
              </span>
            </div>
          ))}
          <button className="text-mccarthy-red hover:text-mccarthy-dark transition-colors">
            <Search size={20} className={isScrolled ? 'text-gray-800' : 'text-white'} />
          </button>
          <a 
            href="#contact" 
            className="bg-mccarthy-red text-white px-6 py-2 uppercase font-bold text-sm tracking-wider hover:bg-red-700 transition-colors"
          >
            Work With Us
          </a>
        </div>

        {/* Mobile Menu Button */}
        <div className="lg:hidden">
          <button 
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className={isScrolled ? 'text-mccarthy-dark' : 'text-white'}
          >
            {isMobileMenuOpen ? <X size={28} /> : <Menu size={28} />}
          </button>
        </div>
      </div>

      {/* Mobile Menu Overlay */}
      {isMobileMenuOpen && (
        <div className="lg:hidden absolute top-full left-0 w-full bg-white shadow-xl py-6 px-6 flex flex-col space-y-4">
          {navLinks.map((link) => (
            <a key={link.name} href="#" className="text-xl font-header font-bold text-mccarthy-dark border-b border-gray-100 pb-2">
              {link.name}
            </a>
          ))}
          <a href="#" className="bg-mccarthy-red text-white text-center py-3 font-bold uppercase mt-4">
            Contact Us
          </a>
        </div>
      )}
    </nav>
  );
};

export default Navbar;