import React from 'react';
import { Project } from '../types';

const projects: Project[] = [
  {
    id: 1,
    title: "Children's Hospital Tower",
    location: "St. Louis, MO",
    category: "Healthcare",
    imageUrl: "https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?q=80&w=2053&auto=format&fit=crop"
  },
  {
    id: 2,
    title: "Solar Farm Expansion",
    location: "Nevada Desert",
    category: "Renewable Energy",
    imageUrl: "https://images.unsplash.com/photo-1509391366360-2e959784a276?q=80&w=2072&auto=format&fit=crop"
  },
  {
    id: 3,
    title: "Tech Campus Innovation Hub",
    location: "Austin, TX",
    category: "Commercial",
    imageUrl: "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?q=80&w=2070&auto=format&fit=crop"
  },
  {
    id: 4,
    title: "International Airport Terminal",
    location: "Los Angeles, CA",
    category: "Aviation",
    imageUrl: "https://images.unsplash.com/photo-1530521954074-e64f6810b32d?q=80&w=2070&auto=format&fit=crop"
  }
];

const FeaturedProjects: React.FC = () => {
  return (
    <section className="py-20 bg-mccarthy-dark text-white">
      <div className="container mx-auto px-6">
        <div className="flex flex-col md:flex-row justify-between items-end mb-12">
          <div>
            <span className="text-mccarthy-red font-header font-bold uppercase tracking-widest text-sm">Portfolio</span>
            <h2 className="text-4xl md:text-5xl font-header font-bold mt-2">Featured Projects</h2>
          </div>
          <button className="hidden md:block border border-white/30 px-6 py-3 uppercase text-sm font-bold tracking-wider hover:bg-white hover:text-mccarthy-dark transition-all">
            View All Projects
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {projects.map((project) => (
            <div key={project.id} className="group relative overflow-hidden h-[400px] cursor-pointer">
              {/* Image */}
              <img 
                src={project.imageUrl} 
                alt={project.title}
                className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
              />
              {/* Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent opacity-80 group-hover:opacity-90 transition-opacity"></div>
              
              {/* Content */}
              <div className="absolute bottom-0 left-0 w-full p-8 translate-y-4 group-hover:translate-y-0 transition-transform duration-500">
                <span className="text-mccarthy-red text-sm font-bold uppercase tracking-wider block mb-2">
                  {project.category}
                </span>
                <h3 className="text-2xl md:text-3xl font-header font-bold mb-1 group-hover:text-white transition-colors">
                  {project.title}
                </h3>
                <p className="text-gray-400 font-light mb-4">{project.location}</p>
                <div className="h-0.5 w-12 bg-mccarthy-red opacity-0 group-hover:opacity-100 transition-opacity duration-500 delay-100"></div>
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-8 text-center md:hidden">
          <button className="border border-white/30 px-6 py-3 uppercase text-sm font-bold tracking-wider hover:bg-white hover:text-mccarthy-dark transition-all">
            View All Projects
          </button>
        </div>
      </div>
    </section>
  );
};

export default FeaturedProjects;