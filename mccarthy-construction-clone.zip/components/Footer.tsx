import React from 'react';
import { Facebook, Twitter, Linkedin, Instagram, Youtube } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-neutral-900 text-white pt-20 pb-10">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16 border-b border-gray-800 pb-12">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-2 mb-6">
               <div className="w-8 h-8 bg-mccarthy-red flex items-center justify-center text-white font-bold font-header text-lg">
                M
              </div>
              <span className="font-header font-bold text-2xl uppercase tracking-tighter">McCarthy</span>
            </div>
            <p className="text-gray-400 text-sm leading-relaxed mb-6">
              The oldest American-owned construction company with a commitment to our employees, our communities, and our clients.
            </p>
            <div className="flex gap-4">
              <Linkedin size={20} className="text-gray-400 hover:text-white cursor-pointer transition-colors" />
              <Facebook size={20} className="text-gray-400 hover:text-white cursor-pointer transition-colors" />
              <Twitter size={20} className="text-gray-400 hover:text-white cursor-pointer transition-colors" />
              <Instagram size={20} className="text-gray-400 hover:text-white cursor-pointer transition-colors" />
            </div>
          </div>

          {/* Links */}
          <div>
            <h4 className="font-header font-bold uppercase tracking-wider text-sm mb-6">Company</h4>
            <ul className="space-y-3 text-sm text-gray-400">
              <li><a href="#" className="hover:text-mccarthy-red transition-colors">About Us</a></li>
              <li><a href="#" className="hover:text-mccarthy-red transition-colors">Leadership</a></li>
              <li><a href="#" className="hover:text-mccarthy-red transition-colors">History</a></li>
              <li><a href="#" className="hover:text-mccarthy-red transition-colors">Community Involvement</a></li>
              <li><a href="#" className="hover:text-mccarthy-red transition-colors">News & Insights</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-header font-bold uppercase tracking-wider text-sm mb-6">Services</h4>
            <ul className="space-y-3 text-sm text-gray-400">
              <li><a href="#" className="hover:text-mccarthy-red transition-colors">Preconstruction</a></li>
              <li><a href="#" className="hover:text-mccarthy-red transition-colors">General Contracting</a></li>
              <li><a href="#" className="hover:text-mccarthy-red transition-colors">Construction Management</a></li>
              <li><a href="#" className="hover:text-mccarthy-red transition-colors">Design-Build</a></li>
              <li><a href="#" className="hover:text-mccarthy-red transition-colors">Virtual Design & Construction</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-header font-bold uppercase tracking-wider text-sm mb-6">Contact</h4>
            <ul className="space-y-3 text-sm text-gray-400">
              <li className="flex flex-col">
                <span className="text-white font-bold">Headquarters</span>
                <span>1234 Construction Way</span>
                <span>St. Louis, MO 63141</span>
              </li>
              <li className="mt-4">
                <span className="block text-white font-bold">Phone</span>
                <a href="tel:5555555555" className="hover:text-mccarthy-red">314-555-0100</a>
              </li>
              <li className="mt-4">
                <a href="#" className="inline-block bg-white text-neutral-900 px-6 py-2 font-bold uppercase text-xs tracking-wider hover:bg-mccarthy-red hover:text-white transition-colors">
                  Contact Us
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="flex flex-col md:flex-row justify-between items-center text-xs text-gray-500">
          <p>&copy; {new Date().getFullYear()} McCarthy Building Companies, Inc. All Rights Reserved.</p>
          <div className="flex gap-6 mt-4 md:mt-0">
            <a href="#" className="hover:text-white">Privacy Policy</a>
            <a href="#" className="hover:text-white">Terms of Use</a>
            <a href="#" className="hover:text-white">Sitemap</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;