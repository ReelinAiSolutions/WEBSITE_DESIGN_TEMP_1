import React from 'react';
import { Zap, HeartPulse, GraduationCap, Building2, FlaskConical, Plane } from 'lucide-react';

const Services: React.FC = () => {
  const markets = [
    { title: 'Healthcare', icon: <HeartPulse size={40} />, desc: 'Building the future of patient care.' },
    { title: 'Education', icon: <GraduationCap size={40} />, desc: 'Creating inspiring learning environments.' },
    { title: 'Renewable Energy', icon: <Zap size={40} />, desc: 'Powering the nation with sustainable solutions.' },
    { title: 'Science & Tech', icon: <FlaskConical size={40} />, desc: 'Labs and facilities for innovation.' },
    { title: 'Commercial', icon: <Building2 size={40} />, desc: 'Offices and mixed-use developments.' },
    { title: 'Aviation', icon: <Plane size={40} />, desc: 'Connecting the world through infrastructure.' },
  ];

  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-6">
        <div className="mb-16 text-center">
          <span className="text-mccarthy-red font-header font-bold uppercase tracking-widest text-sm">What We Do</span>
          <h2 className="text-4xl md:text-5xl font-header font-bold text-mccarthy-dark mt-2">
            Diverse Market Expertise
          </h2>
          <div className="w-24 h-1 bg-mccarthy-red mx-auto mt-6"></div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {markets.map((market, idx) => (
            <div key={idx} className="group p-8 border border-gray-100 hover:border-mccarthy-red hover:shadow-2xl transition-all duration-300 bg-white cursor-pointer">
              <div className="text-mccarthy-blue mb-6 group-hover:text-mccarthy-red transition-colors">
                {market.icon}
              </div>
              <h3 className="text-2xl font-header font-bold text-mccarthy-dark mb-3 group-hover:text-mccarthy-red transition-colors">
                {market.title}
              </h3>
              <p className="text-gray-600 leading-relaxed">
                {market.desc}
              </p>
              <div className="mt-6 flex items-center text-sm font-bold uppercase tracking-wider text-mccarthy-dark opacity-0 group-hover:opacity-100 transition-opacity transform translate-y-2 group-hover:translate-y-0">
                Learn More <span className="ml-2 text-mccarthy-red">→</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;