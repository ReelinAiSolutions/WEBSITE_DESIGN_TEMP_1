import React from 'react';
import { ArrowRight } from 'lucide-react';

const Hero: React.FC = () => {
  return (
    <div className="relative h-screen w-full overflow-hidden">
      {/* Background Image */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{ 
          backgroundImage: 'url("https://images.unsplash.com/photo-1541888946425-d81bb19240f5?q=80&w=2070&auto=format&fit=crop")',
        }}
      >
        <div className="absolute inset-0 bg-black/40"></div>
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent"></div>
      </div>

      {/* Content */}
      <div className="relative z-10 h-full container mx-auto px-6 flex flex-col justify-center">
        <div className="max-w-4xl pt-20">
          <h2 className="text-white font-header font-bold text-lg md:text-xl uppercase tracking-[0.2em] mb-4 border-l-4 border-mccarthy-red pl-4">
            100% Employee Owned
          </h2>
          <h1 className="text-white font-header font-bold text-5xl md:text-7xl lg:text-8xl leading-tight mb-8">
            Building America's <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-white to-gray-400">Future, Today.</span>
          </h1>
          <p className="text-gray-200 text-lg md:text-xl max-w-2xl mb-10 font-light leading-relaxed">
            From complex healthcare facilities to renewable energy fields, we are the partner of choice for those who value quality, safety, and certainty.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4">
            <button className="group bg-mccarthy-red text-white px-8 py-4 font-header font-bold uppercase tracking-wider text-sm flex items-center justify-center gap-2 hover:bg-red-700 transition-all">
              View Our Projects
              <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />
            </button>
            <button className="group border-2 border-white text-white px-8 py-4 font-header font-bold uppercase tracking-wider text-sm hover:bg-white hover:text-mccarthy-dark transition-all">
              Learn About Us
            </button>
          </div>
        </div>
      </div>

      {/* Stats ticker at bottom */}
      <div className="absolute bottom-0 left-0 w-full border-t border-white/20 bg-black/60 backdrop-blur-sm hidden md:block">
        <div className="container mx-auto px-6 py-6 flex justify-between text-white">
          <div className="flex flex-col">
            <span className="font-header font-bold text-3xl text-mccarthy-red">160+</span>
            <span className="text-xs uppercase tracking-wider">Years of Excellence</span>
          </div>
          <div className="flex flex-col border-l border-white/20 pl-8">
            <span className="font-header font-bold text-3xl">100%</span>
            <span className="text-xs uppercase tracking-wider">Employee Owned</span>
          </div>
          <div className="flex flex-col border-l border-white/20 pl-8">
            <span className="font-header font-bold text-3xl">$5B+</span>
            <span className="text-xs uppercase tracking-wider">Annual Revenue</span>
          </div>
          <div className="flex flex-col border-l border-white/20 pl-8 pr-12">
            <span className="font-header font-bold text-3xl">Top 20</span>
            <span className="text-xs uppercase tracking-wider">ENR Green Contractor</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Hero;