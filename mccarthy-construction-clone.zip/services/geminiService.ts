import { GoogleGenAI, Chat, GenerateContentResponse } from "@google/genai";

let chatSession: Chat | null = null;

const getAiClient = () => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    console.warn("API_KEY is missing from environment variables.");
    // In a real app, we might handle this gracefully, but for now we assume it exists or fail.
  }
  return new GoogleGenAI({ apiKey: apiKey || 'DUMMY_KEY_FOR_Types' });
};

export const initializeChat = () => {
  const ai = getAiClient();
  try {
    chatSession = ai.chats.create({
      model: 'gemini-2.5-flash',
      config: {
        systemInstruction: `You are the virtual assistant for McCarthy Building Companies, a 100% employee-owned top national builder. 
        Tone: Professional, knowledgeable, safety-focused, and confident.
        Topics: Construction services, safety culture ("Safety First"), employee ownership (ESOP), diverse markets (healthcare, renewable energy, science & technology).
        Constraint: Keep answers concise (under 100 words) and suitable for a website chat widget.
        If asked about specific live project data, politely say you don't have access to real-time internal databases but can discuss general capabilities.`,
      },
    });
  } catch (error) {
    console.error("Failed to initialize chat session:", error);
  }
};

export const sendMessageToGemini = async (message: string): Promise<string> => {
  if (!chatSession) {
    initializeChat();
  }
  
  if (!chatSession) {
    return "I'm having trouble connecting to our servers right now. Please try again later.";
  }

  try {
    const result: GenerateContentResponse = await chatSession.sendMessage({ message });
    return result.text || "I didn't catch that. Could you rephrase?";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "I apologize, but I'm unable to process your request at the moment.";
  }
};
