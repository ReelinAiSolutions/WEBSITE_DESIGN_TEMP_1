export interface Project {
  id: number;
  title: string;
  location: string;
  category: string;
  imageUrl: string;
}

export interface Market {
  name: string;
  icon: string;
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
}
