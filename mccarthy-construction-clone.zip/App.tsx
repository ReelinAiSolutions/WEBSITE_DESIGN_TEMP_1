import React from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Services from './components/Services';
import FeaturedProjects from './components/FeaturedProjects';
import ChatWidget from './components/ChatWidget';
import Footer from './components/Footer';

function App() {
  return (
    <div className="min-h-screen bg-gray-50 font-sans text-gray-900">
      <Navbar />
      
      <main>
        <Hero />
        
        {/* Culture Teaser Section */}
        <section className="bg-mccarthy-gray py-20">
          <div className="container mx-auto px-6 flex flex-col md:flex-row items-center gap-12">
            <div className="md:w-1/2">
              <span className="text-mccarthy-red font-header font-bold uppercase tracking-widest text-sm">Our Culture</span>
              <h2 className="text-4xl md:text-5xl font-header font-bold text-mccarthy-dark mt-2 mb-6">
                All In on Ownership
              </h2>
              <p className="text-gray-600 text-lg leading-relaxed mb-8">
                As a 100% employee-owned company, every McCarthy partner has a personal stake in the success of your project. This ownership culture drives our commitment to quality, safety, and client satisfaction. We don't just build buildings; we build legacies.
              </p>
              <button className="bg-transparent border-2 border-mccarthy-dark text-mccarthy-dark px-8 py-3 font-header font-bold uppercase tracking-wider text-sm hover:bg-mccarthy-dark hover:text-white transition-all">
                Discover Our Culture
              </button>
            </div>
            <div className="md:w-1/2 relative">
               <div className="absolute top-4 left-4 w-full h-full border-4 border-mccarthy-red hidden md:block"></div>
               <img 
                 src="https://images.unsplash.com/photo-1531482615713-2afd69097998?q=80&w=2070&auto=format&fit=crop" 
                 alt="McCarthy Employee Owners" 
                 className="relative z-10 w-full shadow-xl"
               />
            </div>
          </div>
        </section>

        <FeaturedProjects />
        <Services />
        
        {/* Call to Action */}
        <section className="bg-mccarthy-red py-24 relative overflow-hidden">
          <div className="absolute inset-0 bg-black/10"></div>
          <div className="container mx-auto px-6 relative z-10 text-center text-white">
            <h2 className="text-4xl md:text-6xl font-header font-bold mb-6">Ready to Build?</h2>
            <p className="text-xl md:text-2xl font-light mb-10 max-w-3xl mx-auto">
              Partner with the team that's committed to your vision from day one.
            </p>
            <button className="bg-white text-mccarthy-red px-10 py-4 font-header font-bold uppercase tracking-widest text-sm hover:bg-mccarthy-dark hover:text-white transition-all shadow-lg">
              Start Your Project
            </button>
          </div>
        </section>
      </main>

      <Footer />
      <ChatWidget />
    </div>
  );
}

export default App;