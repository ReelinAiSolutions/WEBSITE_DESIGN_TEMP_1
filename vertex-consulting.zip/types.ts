export interface ServiceItem {
  id: number;
  title: string;
  description: string;
  iconName: 'BarChart' | 'Globe' | 'Cpu' | 'Shield' | 'Users' | 'Zap';
}

export interface TestimonialItem {
  id: number;
  quote: string;
  author: string;
  role: string;
  company: string;
  logoUrl?: string;
}

export interface NavItem {
  label: string;
  href: string;
}