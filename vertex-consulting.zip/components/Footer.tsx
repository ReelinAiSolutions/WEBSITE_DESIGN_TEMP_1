import React from 'react';
import { NavItem } from '../types';

const FOOTER_LINKS: { title: string; items: NavItem[] }[] = [
  {
    title: 'Company',
    items: [
      { label: 'About', href: '#about' },
      { label: 'Careers', href: '#' },
      { label: 'Press', href: '#' },
      { label: 'Impact', href: '#' },
    ]
  },
  {
    title: 'Services',
    items: [
      { label: 'Strategy', href: '#' },
      { label: 'Technology', href: '#' },
      { label: 'Analytics', href: '#' },
      { label: 'Digital', href: '#' },
    ]
  },
  {
    title: 'Legal',
    items: [
      { label: 'Privacy Policy', href: '#' },
      { label: 'Terms of Service', href: '#' },
      { label: 'Cookie Policy', href: '#' },
    ]
  }
];

export const Footer: React.FC = () => {
  return (
    <footer className="bg-white border-t border-slate-100 pt-16 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 lg:gap-12 mb-12">
          
          <div className="col-span-2 md:col-span-1">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-6 h-6 bg-slate-900 rounded-md flex items-center justify-center">
                <span className="text-white font-bold text-xs">V</span>
              </div>
              <span className="font-bold text-lg text-slate-900">Vertex</span>
            </div>
            <p className="text-slate-500 text-sm leading-relaxed mb-4">
              Empowering organizations to achieve sustainable growth through strategic innovation and operational excellence.
            </p>
          </div>

          {FOOTER_LINKS.map((section) => (
            <div key={section.title}>
              <h4 className="font-bold text-slate-900 mb-4">{section.title}</h4>
              <ul className="space-y-2">
                {section.items.map((link) => (
                  <li key={link.label}>
                    <a href={link.href} className="text-sm text-slate-500 hover:text-slate-900 transition-colors">
                      {link.label}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}

        </div>
        
        <div className="border-t border-slate-100 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-xs text-slate-400">
            &copy; {new Date().getFullYear()} Vertex Consulting Group. All rights reserved.
          </p>
          <div className="flex gap-4">
            {/* Social Placeholders */}
            <div className="w-5 h-5 bg-slate-200 rounded-full hover:bg-slate-300 transition-colors cursor-pointer"></div>
            <div className="w-5 h-5 bg-slate-200 rounded-full hover:bg-slate-300 transition-colors cursor-pointer"></div>
            <div className="w-5 h-5 bg-slate-200 rounded-full hover:bg-slate-300 transition-colors cursor-pointer"></div>
          </div>
        </div>
      </div>
    </footer>
  );
};