import React from 'react';
import { TestimonialItem } from '../types';
import { Quote } from 'lucide-react';

const TESTIMONIALS: TestimonialItem[] = [
  {
    id: 1,
    quote: "Vertex helped us navigate a complex merger with incredible precision. Their strategic insight was the difference between success and stagnation.",
    author: "Elena Rodriguez",
    role: "Chief Operating Officer",
    company: "Apex Global Solutions"
  },
  {
    id: 2,
    quote: "The digital transformation roadmap they provided has increased our operational efficiency by 40% in just under six months.",
    author: "James Chen",
    role: "VP of Technology",
    company: "Novus Systems"
  },
  {
    id: 3,
    quote: "Professional, punctual, and profoundly knowledgeable. They didn't just give us a report; they gave us a future.",
    author: "Sarah Jenkins",
    role: "Director of Strategy",
    company: "Meridian Financial"
  }
];

export const Testimonials: React.FC = () => {
  return (
    <section id="testimonials" className="py-20 lg:py-32 bg-slate-900 text-white relative overflow-hidden">
      {/* Abstract Background pattern */}
      <div className="absolute top-0 left-0 w-full h-full opacity-10">
        <svg className="h-full w-full" viewBox="0 0 100 100" preserveAspectRatio="none">
           <path d="M0 100 C 20 0 50 0 100 100 Z" fill="white" />
        </svg>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-3xl lg:text-4xl font-bold mb-6">Trusted by Industry Leaders</h2>
          <p className="text-slate-400 text-lg max-w-2xl mx-auto">
            Our value is best measured by the success of our clients. Here is what they have to say about working with Vertex.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {TESTIMONIALS.map((item) => (
            <div key={item.id} className="bg-slate-800/50 backdrop-blur-sm p-8 rounded-2xl border border-slate-700">
              <Quote className="w-8 h-8 text-slate-500 mb-6" />
              <p className="text-lg text-slate-200 mb-8 italic leading-relaxed">
                "{item.quote}"
              </p>
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 bg-slate-600 rounded-full flex items-center justify-center font-bold text-white">
                  {item.author.charAt(0)}
                </div>
                <div>
                  <h4 className="font-semibold text-white">{item.author}</h4>
                  <p className="text-sm text-slate-400">{item.role}, {item.company}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
        
        {/* Simple Logo Strip */}
        <div className="mt-20 pt-10 border-t border-slate-800 flex flex-wrap justify-center gap-12 opacity-50 grayscale">
            {/* Using text placeholders for logos for simplicity */}
            <span className="text-xl font-bold text-slate-400">ACME CORP</span>
            <span className="text-xl font-bold text-slate-400">GLOBEX</span>
            <span className="text-xl font-bold text-slate-400">SOYLENT</span>
            <span className="text-xl font-bold text-slate-400">UMBRELLA</span>
            <span className="text-xl font-bold text-slate-400">MASSIVE DYNAMIC</span>
        </div>
      </div>
    </section>
  );
};