import React from 'react';

export const About: React.FC = () => {
  return (
    <section id="about" className="py-20 lg:py-32 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          
          <div className="order-2 lg:order-1 relative">
             <div className="grid grid-cols-2 gap-4">
               <img 
                 src="https://picsum.photos/400/500?random=2" 
                 alt="Team working on whiteboard" 
                 className="rounded-2xl object-cover w-full h-64 md:h-80 shadow-lg"
               />
               <img 
                 src="https://picsum.photos/400/500?random=3" 
                 alt="Modern office architecture" 
                 className="rounded-2xl object-cover w-full h-64 md:h-80 shadow-lg mt-8"
               />
             </div>
             {/* Decorative Element */}
             <div className="absolute -z-10 top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[120%] h-[80%] bg-slate-50 rounded-full blur-3xl opacity-60" />
          </div>

          <div className="order-1 lg:order-2">
            <h2 className="text-3xl lg:text-4xl font-bold text-slate-900 mb-6">
              Defining the Future of <br className="hidden lg:block"/> Corporate Excellence
            </h2>
            
            <div className="space-y-6 text-lg text-slate-600">
              <p>
                Founded on the principles of integrity, innovation, and impact, Vertex has grown from a boutique strategy firm into a global powerhouse for enterprise transformation.
              </p>
              <p>
                We don't just advise; we partner. Our cross-functional teams embed themselves within your organization to understand the unique challenges and opportunities that define your market landscape.
              </p>
            </div>

            <div className="grid grid-cols-2 gap-8 mt-10 pt-10 border-t border-slate-100">
              <div>
                <h4 className="text-4xl font-bold text-slate-900 mb-1">15+</h4>
                <p className="text-slate-500 text-sm font-medium">Years of Excellence</p>
              </div>
              <div>
                <h4 className="text-4xl font-bold text-slate-900 mb-1">200+</h4>
                <p className="text-slate-500 text-sm font-medium">Projects Delivered</p>
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};