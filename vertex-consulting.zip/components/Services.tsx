import React from 'react';
import { BarChart2, Globe, Cpu, Shield, Users, Zap } from 'lucide-react';
import { ServiceItem } from '../types';

const SERVICES: ServiceItem[] = [
  {
    id: 1,
    title: 'Strategic Consulting',
    description: 'Data-driven insights to guide your executive decisions and market positioning for maximum impact.',
    iconName: 'BarChart'
  },
  {
    id: 2,
    title: 'Digital Transformation',
    description: 'Modernizing legacy systems and implementing cutting-edge digital workflows for efficiency.',
    iconName: 'Cpu'
  },
  {
    id: 3,
    title: 'Global Expansion',
    description: 'Navigating international markets with regulatory compliance and localized operational frameworks.',
    iconName: 'Globe'
  },
  {
    id: 4,
    title: 'Cybersecurity Audit',
    description: 'Protecting your most valuable assets with enterprise-grade security protocols and risk assessment.',
    iconName: 'Shield'
  },
  {
    id: 5,
    title: 'Talent Acquisition',
    description: 'Building high-performance teams by connecting you with top-tier industry leadership and talent.',
    iconName: 'Users'
  },
  {
    id: 6,
    title: 'Innovation Labs',
    description: 'Rapid prototyping and MVP development to test new ideas before full-scale market launch.',
    iconName: 'Zap'
  },
];

const IconMap: Record<string, React.ElementType> = {
  BarChart: BarChart2,
  Globe: Globe,
  Cpu: Cpu,
  Shield: Shield,
  Users: Users,
  Zap: Zap,
};

export const Services: React.FC = () => {
  return (
    <section id="services" className="py-20 lg:py-32 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="text-center max-w-3xl mx-auto mb-16 lg:mb-24">
          <h2 className="text-3xl lg:text-4xl font-bold text-slate-900 mb-6">
            Expertise That Drives Results
          </h2>
          <p className="text-lg text-slate-600">
            We combine deep industry knowledge with technical expertise to create 
            holistic solutions for the modern enterprise.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 lg:gap-12">
          {SERVICES.map((service) => {
            const Icon = IconMap[service.iconName];
            return (
              <div 
                key={service.id} 
                className="group bg-white p-8 rounded-2xl shadow-sm hover:shadow-md transition-all duration-300 border border-slate-100 hover:border-slate-200"
              >
                <div className="w-12 h-12 bg-slate-100 rounded-lg flex items-center justify-center mb-6 group-hover:bg-slate-900 transition-colors duration-300">
                  <Icon className="w-6 h-6 text-slate-900 group-hover:text-white transition-colors duration-300" />
                </div>
                <h3 className="text-xl font-bold text-slate-900 mb-3">{service.title}</h3>
                <p className="text-slate-600 leading-relaxed">
                  {service.description}
                </p>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};