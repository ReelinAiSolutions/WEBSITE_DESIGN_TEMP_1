import React from 'react';
import { Button } from './Button';
import { Mail, MapPin, Phone } from 'lucide-react';

export const Contact: React.FC = () => {
  return (
    <section id="contact" className="py-20 lg:py-32 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-5xl mx-auto bg-white rounded-3xl shadow-xl overflow-hidden">
          <div className="grid grid-cols-1 lg:grid-cols-2">
            
            {/* Info Side */}
            <div className="bg-slate-900 p-10 lg:p-16 text-white flex flex-col justify-between">
              <div>
                <h3 className="text-2xl font-bold mb-6">Let's Discuss Your Future</h3>
                <p className="text-slate-300 mb-10 leading-relaxed">
                  Ready to optimize your operations or expand into new markets? 
                  Schedule a consultation with our senior partners today.
                </p>
                
                <div className="space-y-6">
                  <div className="flex items-start gap-4">
                    <MapPin className="w-6 h-6 text-slate-400 mt-1" />
                    <div>
                      <p className="font-medium text-white">Headquarters</p>
                      <p className="text-slate-400 text-sm">1200 Financial District Blvd, Suite 400<br/>New York, NY 10005</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-4">
                    <Mail className="w-6 h-6 text-slate-400" />
                    <div>
                      <p className="font-medium text-white">Email Us</p>
                      <p className="text-slate-400 text-sm">hello@vertexconsulting.com</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-4">
                    <Phone className="w-6 h-6 text-slate-400" />
                    <div>
                      <p className="font-medium text-white">Call Us</p>
                      <p className="text-slate-400 text-sm">+1 (555) 123-4567</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="mt-12 lg:mt-0">
                <p className="text-xs text-slate-500">© 2024 Vertex Consulting. All rights reserved.</p>
              </div>
            </div>

            {/* Form Side */}
            <div className="p-10 lg:p-16 bg-white">
              <form className="space-y-6" onSubmit={(e) => e.preventDefault()}>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label htmlFor="firstName" className="block text-sm font-medium text-slate-700 mb-2">First Name</label>
                    <input 
                      type="text" 
                      id="firstName" 
                      className="w-full px-4 py-3 rounded-lg bg-slate-50 border border-slate-200 focus:border-slate-900 focus:ring-0 transition-colors outline-none"
                      placeholder="Jane"
                    />
                  </div>
                  <div>
                    <label htmlFor="lastName" className="block text-sm font-medium text-slate-700 mb-2">Last Name</label>
                    <input 
                      type="text" 
                      id="lastName" 
                      className="w-full px-4 py-3 rounded-lg bg-slate-50 border border-slate-200 focus:border-slate-900 focus:ring-0 transition-colors outline-none"
                      placeholder="Doe"
                    />
                  </div>
                </div>

                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-slate-700 mb-2">Email Address</label>
                  <input 
                    type="email" 
                    id="email" 
                    className="w-full px-4 py-3 rounded-lg bg-slate-50 border border-slate-200 focus:border-slate-900 focus:ring-0 transition-colors outline-none"
                    placeholder="jane@company.com"
                  />
                </div>

                <div>
                  <label htmlFor="interest" className="block text-sm font-medium text-slate-700 mb-2">Area of Interest</label>
                  <select 
                    id="interest" 
                    className="w-full px-4 py-3 rounded-lg bg-slate-50 border border-slate-200 focus:border-slate-900 focus:ring-0 transition-colors outline-none text-slate-600"
                  >
                    <option>Strategic Consulting</option>
                    <option>Digital Transformation</option>
                    <option>Mergers & Acquisitions</option>
                    <option>Other</option>
                  </select>
                </div>

                <div>
                  <label htmlFor="message" className="block text-sm font-medium text-slate-700 mb-2">Message</label>
                  <textarea 
                    id="message" 
                    rows={4}
                    className="w-full px-4 py-3 rounded-lg bg-slate-50 border border-slate-200 focus:border-slate-900 focus:ring-0 transition-colors outline-none resize-none"
                    placeholder="Tell us about your project needs..."
                  ></textarea>
                </div>

                <Button type="submit" fullWidth size="lg">Send Message</Button>
              </form>
            </div>

          </div>
        </div>
      </div>
    </section>
  );
};