export interface Beer {
  id: string;
  name: string;
  tagline: string;
  description: string;
  abv: string;
  type: string;
  color: string;
  accentColor: string;
  price: number;
}

export interface RecommendationResponse {
  beerId: string;
  reasoning: string;
  funFact: string;
}

export enum LoadingState {
  IDLE = 'IDLE',
  LOADING = 'LOADING',
  SUCCESS = 'SUCCESS',
  ERROR = 'ERROR'
}