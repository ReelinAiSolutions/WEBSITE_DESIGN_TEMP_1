import { GoogleGenAI, Type } from "@google/genai";
import { BEERS } from "../constants";
import { RecommendationResponse } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getBeerRecommendation = async (userPreference: string): Promise<RecommendationResponse> => {
  const beerListString = BEERS.map(b => `${b.id}: ${b.name} (${b.type}, ${b.description})`).join('\n');

  const prompt = `
    User Preference: "${userPreference}"
    
    Available Beers:
    ${beerListString}
    
    Task: Select the single best beer match from the available list for this user. 
    Explain why in a fun, nautical, or whimsical "Twin Sails" brand voice.
    Also provide a made-up "fun fact" about this specific batch.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            beerId: { type: Type.STRING, description: "The ID of the selected beer" },
            reasoning: { type: Type.STRING, description: "A fun, persuasive reason why this beer fits the user." },
            funFact: { type: Type.STRING, description: "A whimsical, made-up fact about this beer." },
          },
          required: ["beerId", "reasoning", "funFact"]
        }
      }
    });

    if (response.text) {
      return JSON.parse(response.text) as RecommendationResponse;
    }
    throw new Error("No response text");
  } catch (error) {
    console.error("Gemini API Error:", error);
    // Fallback in case of error
    return {
      beerId: 'dat-juice',
      reasoning: "The seas are a bit choppy (AI error), but you can never go wrong with our classic Dat Juice!",
      funFact: "This fallback message was brewed with 100% love."
    };
  }
};