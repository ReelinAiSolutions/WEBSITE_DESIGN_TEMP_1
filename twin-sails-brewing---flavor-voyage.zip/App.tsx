import React, { useState } from 'react';
import { Menu, ShoppingBag, X } from 'lucide-react';
import { BEERS, NAV_LINKS } from './constants';
import { BeerCard } from './components/BeerCard';
import { Marquee } from './components/Marquee';
import { CaptainAI } from './components/CaptainAI';
import { Button } from './components/Button';

const App: React.FC = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  return (
    <div className="min-h-screen flex flex-col overflow-x-hidden">
      
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 p-4 md:p-6">
        <div className="bg-white/80 backdrop-blur-md border border-white/50 rounded-full px-6 py-4 flex items-center justify-between shadow-sm max-w-7xl mx-auto">
          {/* Mobile Menu Button */}
          <button onClick={() => setIsMobileMenuOpen(true)} className="md:hidden p-2">
            <Menu size={24} />
          </button>

          {/* Logo */}
          <a href="#" className="text-2xl font-serif font-black tracking-tighter text-ts-blue">
            TWIN SAILS
          </a>

          {/* Desktop Links */}
          <div className="hidden md:flex items-center gap-8">
            {NAV_LINKS.map((link) => (
              <a 
                key={link.name} 
                href={link.href} 
                className="font-sans font-medium text-ts-blue hover:text-ts-orange transition-colors"
              >
                {link.name}
              </a>
            ))}
          </div>

          {/* Cart */}
          <button className="relative p-2 group">
            <ShoppingBag size={24} className="text-ts-blue group-hover:text-ts-orange transition-colors" />
            <span className="absolute top-0 right-0 bg-ts-orange text-ts-blue text-xs font-bold w-5 h-5 rounded-full flex items-center justify-center">0</span>
          </button>
        </div>
      </nav>

      {/* Mobile Menu Overlay */}
      {isMobileMenuOpen && (
        <div className="fixed inset-0 z-[60] bg-ts-cream flex flex-col p-6">
          <div className="flex justify-between items-center mb-12">
            <span className="text-2xl font-serif font-black">TWIN SAILS</span>
            <button onClick={() => setIsMobileMenuOpen(false)}><X size={32} /></button>
          </div>
          <div className="flex flex-col gap-6 text-3xl font-serif font-bold">
            {NAV_LINKS.map((link) => (
              <a 
                key={link.name} 
                href={link.href} 
                onClick={() => setIsMobileMenuOpen(false)}
                className="hover:text-ts-orange"
              >
                {link.name}
              </a>
            ))}
          </div>
        </div>
      )}

      {/* Hero Section */}
      <header className="pt-32 pb-12 md:pt-48 md:pb-24 px-4 relative overflow-hidden">
        <div className="max-w-7xl mx-auto grid md:grid-cols-2 gap-12 items-center">
          <div className="relative z-10 space-y-8">
            <div className="inline-block bg-ts-orange/20 text-ts-orange px-4 py-2 rounded-full font-bold font-sans tracking-wide uppercase text-sm">
              Fresh from Port Moody
            </div>
            <h1 className="text-6xl md:text-8xl font-serif font-medium leading-[0.9] text-ts-blue">
              Taste the <br/>
              <span className="italic text-ts-orange">Uncharted.</span>
            </h1>
            <p className="text-xl md:text-2xl font-sans text-ts-blue/70 max-w-md leading-relaxed">
              Progressive beers for the curious drinker. Hazy IPAs, complex stouts, and fruited sours that push the boundaries.
            </p>
            <div className="flex gap-4">
              <Button>Shop All Beer</Button>
              <Button variant="outline">Our Story</Button>
            </div>
          </div>

          {/* Hero Image / Graphic */}
          <div className="relative h-[50vh] md:h-[70vh] flex items-center justify-center">
            {/* Abstract Background Blobs */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[120%] h-[120%] bg-ts-light-blue rounded-full opacity-30 blur-3xl animate-pulse"></div>
            <div className="absolute top-1/4 right-10 w-48 h-48 bg-ts-pink rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-float"></div>
            <div className="absolute bottom-1/4 left-10 w-64 h-64 bg-ts-yellow rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-float" style={{ animationDelay: '2s' }}></div>
            
            {/* Hero Can */}
             <div className="relative z-10 w-64 h-[28rem] bg-white rounded-3xl border-4 border-black shadow-2xl flex flex-col items-center justify-center overflow-hidden transform -rotate-6 transition-transform hover:rotate-0 duration-700">
                <div className="absolute inset-0 bg-ts-yellow opacity-80"></div>
                <h2 className="relative z-10 text-6xl font-serif font-black text-black transform -rotate-90 whitespace-nowrap">DAT JUICE</h2>
            </div>
          </div>
        </div>
      </header>

      {/* Marquee */}
      <div className="bg-ts-blue text-ts-cream py-6 border-y-4 border-black transform -rotate-1 origin-left scale-105 z-20">
        <Marquee text="• UNFILTERED • UNPASTEURIZED • BREWED IN BC • ALWAYS FRESH • KEEP COLD • DRINK FRESH •" className="font-serif text-2xl font-bold tracking-wider" />
      </div>

      {/* Product Grid */}
      <section className="py-24 px-4 bg-white relative">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16 space-y-4">
            <h2 className="text-5xl md:text-6xl font-serif text-ts-blue">Our Fleet</h2>
            <p className="text-xl font-sans text-ts-blue/60">Small batches, big flavors.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {BEERS.map((beer) => (
              <BeerCard key={beer.id} beer={beer} />
            ))}
          </div>
          
          <div className="text-center mt-16">
            <Button variant="secondary" className="text-xl px-12 py-6">View All Releases</Button>
          </div>
        </div>
      </section>

      {/* AI Recommendation Section */}
      <CaptainAI />

      {/* Footer */}
      <footer className="bg-ts-blue text-ts-cream pt-24 pb-12 px-4">
        <div className="max-w-7xl mx-auto grid md:grid-cols-4 gap-12 mb-16">
          <div className="col-span-1 md:col-span-2 space-y-6">
            <h2 className="text-4xl font-serif font-black">TWIN SAILS</h2>
            <p className="text-lg opacity-80 max-w-sm">
              Brewing progressive ales in Port Moody, BC. Come say hi at the tasting room or order online for delivery.
            </p>
          </div>
          
          <div>
            <h3 className="font-serif font-bold text-2xl mb-6 text-ts-orange">Shop</h3>
            <ul className="space-y-4 font-sans opacity-80">
              <li><a href="#" className="hover:text-ts-orange transition-colors">New Releases</a></li>
              <li><a href="#" className="hover:text-ts-orange transition-colors">Core Lineup</a></li>
              <li><a href="#" className="hover:text-ts-orange transition-colors">Merchandise</a></li>
              <li><a href="#" className="hover:text-ts-orange transition-colors">Gift Cards</a></li>
            </ul>
          </div>

          <div>
            <h3 className="font-serif font-bold text-2xl mb-6 text-ts-orange">Visit</h3>
            <ul className="space-y-4 font-sans opacity-80">
              <li>2821 Murray St</li>
              <li>Port Moody, BC</li>
              <li>Canada</li>
              <li className="pt-4"><a href="#" className="hover:text-ts-orange transition-colors">Hours & Info</a></li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-white/10 pt-8 flex flex-col md:flex-row justify-between items-center text-sm opacity-50 font-sans">
          <p>&copy; {new Date().getFullYear()} Twin Sails Brewing.</p>
          <div className="flex gap-6 mt-4 md:mt-0">
            <a href="#">Instagram</a>
            <a href="#">Facebook</a>
            <a href="#">Untappd</a>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default App;