import React from 'react';

interface MarqueeProps {
  text: string;
  className?: string;
  speed?: 'normal' | 'slow' | 'fast';
}

export const Marquee: React.FC<MarqueeProps> = ({ text, className = "" }) => {
  return (
    <div className={`w-full flex justify-center items-center px-4 ${className}`}>
      <p className="text-center w-full leading-tight">
        {text}
      </p>
    </div>
  );
};