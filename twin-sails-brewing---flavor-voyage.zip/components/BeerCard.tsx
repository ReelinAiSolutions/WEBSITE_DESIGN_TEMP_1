import React from 'react';
import { Beer } from '../types';
import { Button } from './Button';
import { Plus } from 'lucide-react';

interface BeerCardProps {
  beer: Beer;
}

export const BeerCard: React.FC<BeerCardProps> = ({ beer }) => {
  return (
    <div className={`group relative flex flex-col items-center p-8 rounded-[3rem] ${beer.color} transition-all duration-500 hover:scale-[1.02]`}>
      {/* Decorative Blob */}
      <div className="absolute inset-0 overflow-hidden rounded-[3rem] opacity-20 pointer-events-none">
         <div className="absolute -top-10 -right-10 w-40 h-40 bg-white rounded-full blur-2xl"></div>
         <div className="absolute bottom-10 left-10 w-32 h-32 bg-white rounded-full blur-xl"></div>
      </div>

      {/* "Can" Representation - CSS Art */}
      <div className="relative z-10 w-40 h-72 mb-8 transition-transform duration-500 group-hover:rotate-6 group-hover:-translate-y-4">
        <div className="w-full h-full bg-white rounded-2xl shadow-xl border-2 border-black flex flex-col items-center justify-center overflow-hidden relative">
            {/* Can Label Art Mimic */}
            <div className={`absolute inset-0 opacity-80 ${beer.color}`}></div>
            <div className="relative z-10 text-center p-2 transform -rotate-90">
                <h3 className="text-3xl font-serif font-bold text-black whitespace-nowrap">{beer.name.toUpperCase()}</h3>
                <p className="text-xs font-sans tracking-widest mt-1">{beer.tagline}</p>
            </div>
            {/* Can Top/Bottom details */}
            <div className="absolute top-0 w-full h-4 bg-gray-300 border-b-2 border-black"></div>
            <div className="absolute bottom-0 w-full h-4 bg-gray-300 border-t-2 border-black"></div>
        </div>
        {/* Shadow */}
        <div className="absolute -bottom-6 left-1/2 -translate-x-1/2 w-32 h-4 bg-black/20 blur-md rounded-full transition-all group-hover:w-24 group-hover:blur-sm"></div>
      </div>

      <div className="relative z-10 text-center space-y-3 w-full">
        <h3 className="text-3xl font-serif font-bold text-ts-blue leading-tight">{beer.name}</h3>
        <p className={`font-sans font-medium uppercase tracking-wider text-sm ${beer.accentColor}`}>{beer.tagline}</p>
        <p className="font-sans text-ts-blue/80 text-sm line-clamp-3 min-h-[60px]">{beer.description}</p>
        
        <div className="pt-4 w-full">
          <Button variant="outline" fullWidth className="flex items-center justify-center gap-2 group-hover:bg-ts-blue group-hover:text-white border-black text-black">
            <span>Add to Cart - ${beer.price}</span>
            <Plus size={18} />
          </Button>
        </div>
      </div>
    </div>
  );
};