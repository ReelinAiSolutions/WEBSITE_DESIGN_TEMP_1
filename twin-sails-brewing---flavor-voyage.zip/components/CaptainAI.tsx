import React, { useState } from 'react';
import { getBeerRecommendation } from '../services/geminiService';
import { Beer, LoadingState, RecommendationResponse } from '../types';
import { BEERS } from '../constants';
import { Button } from './Button';
import { Sparkles, Anchor, MessageCircle, AlertCircle } from 'lucide-react';

export const CaptainAI: React.FC = () => {
  const [input, setInput] = useState('');
  const [status, setStatus] = useState<LoadingState>(LoadingState.IDLE);
  const [result, setResult] = useState<RecommendationResponse | null>(null);

  const handleAskCaptain = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    setStatus(LoadingState.LOADING);
    try {
      const data = await getBeerRecommendation(input);
      setResult(data);
      setStatus(LoadingState.SUCCESS);
    } catch (error) {
      console.error(error);
      setStatus(LoadingState.ERROR);
    }
  };

  const recommendedBeer = result ? BEERS.find(b => b.id === result.beerId) : null;

  return (
    <section id="ai-concierge" className="py-24 px-4 relative overflow-hidden bg-ts-blue text-ts-cream">
      {/* Background patterns */}
      <div className="absolute top-0 left-0 w-64 h-64 bg-ts-light-blue rounded-full mix-blend-overlay filter blur-3xl opacity-20 animate-pulse"></div>
      <div className="absolute bottom-0 right-0 w-96 h-96 bg-ts-orange rounded-full mix-blend-overlay filter blur-3xl opacity-20"></div>

      <div className="max-w-4xl mx-auto relative z-10 text-center">
        <div className="inline-flex items-center gap-2 bg-ts-cream/10 backdrop-blur-sm px-4 py-2 rounded-full mb-6 border border-white/20">
          <Anchor className="text-ts-orange" size={20} />
          <span className="font-sans text-sm font-semibold tracking-wide">The Captain's Concierge</span>
        </div>
        
        <h2 className="text-5xl md:text-7xl font-serif mb-8 leading-tight">
          Lost at sea? <br/>
          <span className="text-ts-light-blue italic">Find your flavor.</span>
        </h2>
        
        <p className="text-xl md:text-2xl font-sans mb-12 opacity-90 max-w-2xl mx-auto">
          Tell us what you usually drink, and our AI Skipper will steer you toward your perfect pint.
        </p>

        <form onSubmit={handleAskCaptain} className="max-w-xl mx-auto mb-16 relative">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="I like coffee and dark chocolate..."
            className="w-full bg-ts-cream text-ts-blue text-xl p-6 pr-16 rounded-[2rem] placeholder:text-ts-blue/40 focus:outline-none focus:ring-4 focus:ring-ts-orange/50 transition-all font-serif"
            disabled={status === LoadingState.LOADING}
          />
          <button 
            type="submit"
            className="absolute right-3 top-3 bottom-3 aspect-square bg-ts-orange rounded-full flex items-center justify-center text-ts-blue hover:scale-105 transition-transform disabled:opacity-50"
            disabled={status === LoadingState.LOADING || !input}
          >
            {status === LoadingState.LOADING ? (
              <div className="w-6 h-6 border-2 border-ts-blue border-t-transparent rounded-full animate-spin"></div>
            ) : (
              <Sparkles size={24} />
            )}
          </button>
        </form>

        {status === LoadingState.SUCCESS && result && recommendedBeer && (
            <div className="bg-ts-cream text-ts-blue rounded-[3rem] p-8 md:p-12 text-left animate-float shadow-2xl border-4 border-ts-orange">
                <div className="grid md:grid-cols-2 gap-8 items-center">
                    <div>
                        <div className="inline-block bg-ts-orange text-ts-blue px-3 py-1 rounded-full text-xs font-bold uppercase tracking-widest mb-4">
                            Captain's Pick
                        </div>
                        <h3 className="text-4xl font-serif font-bold mb-2">{recommendedBeer.name}</h3>
                        <p className="text-xl text-ts-blue/60 font-sans mb-6">{recommendedBeer.tagline}</p>
                        
                        <div className="bg-ts-light-blue/20 p-6 rounded-2xl mb-6">
                            <div className="flex gap-3 mb-2">
                                <MessageCircle className="shrink-0 text-ts-blue" />
                                <p className="font-serif italic text-lg leading-relaxed">"{result.reasoning}"</p>
                            </div>
                        </div>

                         <div className="flex gap-3 items-start opacity-75">
                                <AlertCircle className="shrink-0 w-5 h-5 mt-1" />
                                <p className="font-sans text-sm"><strong>Fun Fact:</strong> {result.funFact}</p>
                            </div>
                    </div>
                    <div className="relative h-64 md:h-80 flex items-center justify-center bg-white/50 rounded-[2rem]">
                         {/* Simple visual rep of the recommended beer */}
                         <div className={`w-32 h-56 rounded-xl border-4 border-black ${recommendedBeer.color} flex flex-col items-center justify-center shadow-lg transform rotate-3`}>
                             <span className="font-serif font-bold text-xl -rotate-90">{recommendedBeer.name}</span>
                         </div>
                         <Button className="absolute -bottom-6 shadow-xl" variant="secondary">Add to Cart</Button>
                    </div>
                </div>
            </div>
        )}
      </div>
    </section>
  );
};