import { Beer } from './types';

export const BEERS: Beer[] = [
  {
    id: 'dat-juice',
    name: 'Dat Juice',
    tagline: 'Citra Pale Ale',
    description: 'An unfiltered pale ale brewed with large amounts of Citra hops. Juicy, tropical, and incredibly crushable.',
    abv: '5.2%',
    type: 'Pale Ale',
    color: 'bg-ts-yellow',
    accentColor: 'text-yellow-700',
    price: 16.00
  },
  {
    id: 'con-leche',
    name: 'Con Leche',
    tagline: 'Horchata Milk Stout',
    description: 'Sweet, creamy, and spiced with cinnamon and vanilla. Like a dessert in a glass.',
    abv: '7.5%',
    type: 'Stout',
    color: 'bg-stone-200',
    accentColor: 'text-stone-700',
    price: 18.00
  },
  {
    id: 'high-five',
    name: 'High Five',
    tagline: 'Hazy IPA',
    description: 'Packed with Galaxy and Mosaic hops. Big notes of passionfruit, peach, and citrus.',
    abv: '6.8%',
    type: 'IPA',
    color: 'bg-ts-green',
    accentColor: 'text-green-800',
    price: 17.50
  },
  {
    id: 'would-crush',
    name: 'Would Crush',
    tagline: 'Raspberry Wheat Ale',
    description: 'Loaded with massive amounts of raspberry puree. Tart, refreshing, and bright red.',
    abv: '5.1%',
    type: 'Wheat Ale',
    color: 'bg-ts-pink',
    accentColor: 'text-pink-700',
    price: 16.50
  }
];

export const NAV_LINKS = [
  { name: 'Shop Beer', href: '#' },
  { name: 'Merch', href: '#' },
  { name: 'Visit Us', href: '#' },
  { name: 'The Captain', href: '#ai-concierge' } // Anchor to AI section
];