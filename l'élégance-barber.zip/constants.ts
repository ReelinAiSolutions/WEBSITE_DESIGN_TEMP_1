import { Service, Barber, Testimonial } from './types';

export const SERVICES: Service[] = [
  {
    id: '1',
    title: 'The Signature Cut',
    description: 'Precision haircut tailored to your face shape and lifestyle, finished with a hot towel refresher.',
    price: '$65',
    duration: '45 min'
  },
  {
    id: '2',
    title: 'Royal Wet Shave',
    description: 'Traditional straight razor shave with pre-shave oil, hot towels, and post-shave balm massage.',
    price: '$55',
    duration: '30 min'
  },
  {
    id: '3',
    title: 'Beard Sculpting',
    description: 'Expert shaping and trimming of the beard with razor lining and conditioning treatment.',
    price: '$40',
    duration: '30 min'
  },
  {
    id: '4',
    title: 'The Gentleman\'s Experience',
    description: 'Our full service package: Signature Cut, Royal Wet Shave, and a revitalizing facial treatment.',
    price: '$110',
    duration: '90 min'
  }
];

export const BARBERS: Barber[] = [
  {
    id: '1',
    name: 'Elias Thorne',
    role: 'Master Barber',
    image: 'https://picsum.photos/id/1005/400/500' // Placeholder
  },
  {
    id: '2',
    name: 'Marcus Chen',
    role: 'Senior Stylist',
    image: 'https://picsum.photos/id/1012/400/500' // Placeholder
  },
  {
    id: '3',
    name: 'Julian Vane',
    role: 'Grooming Expert',
    image: 'https://picsum.photos/id/338/400/500' // Placeholder
  }
];

export const TESTIMONIALS: Testimonial[] = [
  {
    id: '1',
    name: 'Arthur Sterling',
    role: 'Architect',
    text: '"An oasis of calm and precision. The best shave I have had in the city, bar none."'
  },
  {
    id: '2',
    name: 'James C.',
    role: 'Entrepreneur',
    text: '"L\'Élégance isn\'t just a barber shop; it is a ritual. The attention to detail is immaculate."'
  }
];

export const NAV_LINKS = [
  { name: 'Heritage', href: '#heritage' },
  { name: 'Services', href: '#services' },
  { name: 'Consultant AI', href: '#ai-consultant' },
  { name: 'Atelier', href: '#atelier' },
  { name: 'Contact', href: '#contact' },
];