export interface Service {
  id: string;
  title: string;
  description: string;
  price: string;
  duration: string;
}

export interface Barber {
  id: string;
  name: string;
  role: string;
  image: string;
}

export interface Testimonial {
  id: string;
  name: string;
  text: string;
  role: string;
}

export enum ConsultationState {
  IDLE = 'IDLE',
  LOADING = 'LOADING',
  SUCCESS = 'SUCCESS',
  ERROR = 'ERROR'
}

export interface ConsultationFormData {
  hairType: string;
  faceShape: string;
  stylePreference: string;
  maintenance: string;
}

export interface ConsultationResponse {
  recommendation: string;
  stylingTips: string[];
  suggestedProduct: string;
}