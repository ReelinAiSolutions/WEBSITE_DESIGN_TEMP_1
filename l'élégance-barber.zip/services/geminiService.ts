import { GoogleGenAI, Type } from "@google/genai";
import { ConsultationFormData, ConsultationResponse } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const getStyleConsultation = async (data: ConsultationFormData): Promise<ConsultationResponse> => {
  try {
    const model = 'gemini-2.5-flash';
    
    const prompt = `
      Act as a world-class luxury barber and stylist.
      I have a client with the following attributes:
      - Hair Type: ${data.hairType}
      - Face Shape: ${data.faceShape}
      - Style Preference: ${data.stylePreference}
      - Maintenance Level: ${data.maintenance}

      Provide a sophisticated recommendation for a haircut and beard style (if applicable).
      Also provide styling tips and a suggested product type.
      Keep the tone elegant, professional, and high-end.
    `;

    const response = await ai.models.generateContent({
      model,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            recommendation: { type: Type.STRING },
            stylingTips: { 
              type: Type.ARRAY,
              items: { type: Type.STRING }
            },
            suggestedProduct: { type: Type.STRING }
          },
          required: ["recommendation", "stylingTips", "suggestedProduct"]
        }
      }
    });

    const text = response.text;
    if (!text) throw new Error("No response from AI");
    
    return JSON.parse(text) as ConsultationResponse;

  } catch (error) {
    console.error("Gemini API Error:", error);
    throw new Error("Unable to generate consultation at this time.");
  }
};