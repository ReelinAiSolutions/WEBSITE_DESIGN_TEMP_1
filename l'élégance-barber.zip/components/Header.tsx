import React, { useState, useEffect } from 'react';
import { NAV_LINKS } from '../constants';
import { Menu, X } from 'lucide-react';

export const Header: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header 
      className={`fixed top-0 w-full z-50 transition-all duration-500 border-b ${
        isScrolled 
          ? 'bg-brand-black/95 backdrop-blur-sm py-4 border-brand-gray' 
          : 'bg-transparent py-8 border-transparent'
      }`}
    >
      <div className="container mx-auto px-6 flex justify-between items-center">
        {/* Logo */}
        <div className="flex items-center gap-2 z-50">
           <span className="text-2xl font-serif text-brand-light tracking-widest uppercase cursor-pointer">
             L'Élégance
           </span>
        </div>

        {/* Desktop Nav */}
        <nav className="hidden md:flex items-center gap-8">
          {NAV_LINKS.map((link) => (
            <a 
              key={link.name} 
              href={link.href}
              className="text-xs uppercase tracking-[0.2em] text-brand-light/80 hover:text-brand-gold transition-colors duration-300"
            >
              {link.name}
            </a>
          ))}
          <a 
            href="#book"
            className="ml-4 px-6 py-2 border border-brand-gold text-brand-gold text-xs uppercase tracking-[0.2em] hover:bg-brand-gold hover:text-brand-black transition-all duration-300"
          >
            Book Now
          </a>
        </nav>

        {/* Mobile Toggle */}
        <button 
          className="md:hidden text-brand-light z-50"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        >
          {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>

        {/* Mobile Menu Overlay */}
        <div className={`fixed inset-0 bg-brand-black z-40 transition-transform duration-500 ease-in-out ${isMobileMenuOpen ? 'translate-x-0' : 'translate-x-full'}`}>
          <div className="flex flex-col items-center justify-center h-full gap-8">
            {NAV_LINKS.map((link) => (
              <a 
                key={link.name} 
                href={link.href}
                onClick={() => setIsMobileMenuOpen(false)}
                className="text-2xl font-serif text-brand-light hover:text-brand-gold transition-colors"
              >
                {link.name}
              </a>
            ))}
             <a 
              href="#book"
              onClick={() => setIsMobileMenuOpen(false)}
              className="mt-8 px-10 py-4 border border-brand-gold text-brand-gold text-sm uppercase tracking-[0.2em]"
            >
              Book Appointment
            </a>
          </div>
        </div>
      </div>
    </header>
  );
};