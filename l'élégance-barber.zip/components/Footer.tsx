import React from 'react';

export const Footer: React.FC = () => {
  return (
    <footer id="contact" className="bg-brand-dark pt-24 pb-12 border-t border-brand-gray/20">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-16 mb-20">
          
          <div className="space-y-6">
            <span className="text-2xl font-serif text-brand-light tracking-widest uppercase">
              L'Élégance
            </span>
            <p className="text-brand-muted font-light text-sm leading-7">
              Redefining the art of male grooming with a focus on precision, relaxation, and timeless style.
            </p>
          </div>

          <div className="space-y-6">
            <h4 className="text-brand-gold text-xs uppercase tracking-[0.2em] mb-6">Visit Us</h4>
            <address className="not-italic text-brand-muted font-light text-sm leading-7">
              1428 Avenue of the Americas<br />
              New York, NY 10019<br />
              United States
            </address>
            <p className="text-brand-muted font-light text-sm">
              <span className="block text-brand-light mb-1">Inquiries</span>
              concierge@lelegance-barber.com
            </p>
          </div>

          <div className="space-y-6">
            <h4 className="text-brand-gold text-xs uppercase tracking-[0.2em] mb-6">Hours</h4>
            <ul className="text-brand-muted font-light text-sm leading-7 space-y-2">
              <li className="flex justify-between max-w-[200px]">
                <span>Mon - Fri</span>
                <span className="text-brand-light">09:00 - 20:00</span>
              </li>
              <li className="flex justify-between max-w-[200px]">
                <span>Saturday</span>
                <span className="text-brand-light">10:00 - 18:00</span>
              </li>
              <li className="flex justify-between max-w-[200px]">
                <span>Sunday</span>
                <span className="text-brand-light">Closed</span>
              </li>
            </ul>
          </div>

        </div>

        <div className="flex flex-col md:flex-row justify-between items-center pt-8 border-t border-brand-gray/10 text-xs text-brand-muted font-light">
          <p>&copy; 2024 L'Élégance Barber. All rights reserved.</p>
          <div className="flex gap-6 mt-4 md:mt-0 uppercase tracking-wider">
            <a href="#" className="hover:text-brand-gold transition-colors">Instagram</a>
            <a href="#" className="hover:text-brand-gold transition-colors">Facebook</a>
            <a href="#" className="hover:text-brand-gold transition-colors">Twitter</a>
          </div>
        </div>
      </div>
    </footer>
  );
};