import React from 'react';
import { Button, SectionTitle } from './UI';

export const BookingCta: React.FC = () => {
  return (
    <section id="book" className="py-24 bg-brand-black relative">
      <div className="container mx-auto px-6 text-center">
        <SectionTitle title="Secure Your Experience" centered />
        
        <div className="max-w-2xl mx-auto bg-brand-dark p-8 md:p-12 border border-brand-gray/30">
          <p className="text-brand-muted font-light mb-8">
            Due to high demand, we recommend booking at least 3 days in advance.
          </p>
          
          <form className="space-y-6 text-left" onSubmit={(e) => e.preventDefault()}>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-xs uppercase tracking-widest text-brand-gold mb-2">Name</label>
                <input type="text" className="w-full bg-brand-black border border-brand-gray p-3 text-brand-light focus:border-brand-gold outline-none transition-colors" placeholder="John Doe" />
              </div>
              <div>
                <label className="block text-xs uppercase tracking-widest text-brand-gold mb-2">Phone</label>
                <input type="tel" className="w-full bg-brand-black border border-brand-gray p-3 text-brand-light focus:border-brand-gold outline-none transition-colors" placeholder="+1 (555) 000-0000" />
              </div>
            </div>
            
            <div>
              <label className="block text-xs uppercase tracking-widest text-brand-gold mb-2">Service</label>
              <select className="w-full bg-brand-black border border-brand-gray p-3 text-brand-light focus:border-brand-gold outline-none transition-colors">
                <option>The Signature Cut</option>
                <option>Royal Wet Shave</option>
                <option>The Gentleman's Experience</option>
              </select>
            </div>

            <div className="pt-4">
              <Button className="w-full justify-center">Request Appointment</Button>
            </div>
          </form>
        </div>
      </div>
    </section>
  );
};