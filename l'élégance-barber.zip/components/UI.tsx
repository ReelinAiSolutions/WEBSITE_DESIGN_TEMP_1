import React, { ReactNode } from 'react';

export const Button: React.FC<{ 
  children: ReactNode; 
  onClick?: () => void; 
  variant?: 'primary' | 'outline' | 'text';
  className?: string;
  disabled?: boolean;
}> = ({ children, onClick, variant = 'primary', className = '', disabled = false }) => {
  const baseStyles = "px-8 py-3 uppercase tracking-[0.2em] text-xs transition-all duration-300 ease-out font-medium disabled:opacity-50 disabled:cursor-not-allowed";
  
  const variants = {
    primary: "bg-brand-gold text-brand-black hover:bg-white hover:text-brand-black",
    outline: "border border-brand-gold text-brand-gold hover:bg-brand-gold hover:text-brand-black",
    text: "text-brand-light hover:text-brand-gold underline-offset-4 hover:underline"
  };

  return (
    <button 
      onClick={onClick} 
      className={`${baseStyles} ${variants[variant]} ${className}`}
      disabled={disabled}
    >
      {children}
    </button>
  );
};

export const SectionTitle: React.FC<{ title: string; subtitle?: string; centered?: boolean }> = ({ title, subtitle, centered = true }) => (
  <div className={`mb-16 ${centered ? 'text-center' : 'text-left'}`}>
    {subtitle && (
      <span className="block text-brand-gold text-xs uppercase tracking-[0.3em] mb-4">
        {subtitle}
      </span>
    )}
    <h2 className="text-4xl md:text-5xl font-serif text-brand-light font-light leading-tight">
      {title}
    </h2>
    <div className={`h-px w-24 bg-brand-gold/30 mt-8 ${centered ? 'mx-auto' : ''}`} />
  </div>
);

export const FadeIn: React.FC<{ children: ReactNode; delay?: number }> = ({ children, delay = 0 }) => {
  const [isVisible, setIsVisible] = React.useState(false);
  const domRef = React.useRef<HTMLDivElement>(null);

  React.useEffect(() => {
    const observer = new IntersectionObserver(entries => {
      entries.forEach(entry => setIsVisible(entry.isIntersecting));
    });
    if (domRef.current) observer.observe(domRef.current);
    return () => observer.disconnect();
  }, []);

  return (
    <div
      ref={domRef}
      className={`transition-all duration-1000 ease-out transform ${
        isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
      }`}
      style={{ transitionDelay: `${delay}ms` }}
    >
      {children}
    </div>
  );
};