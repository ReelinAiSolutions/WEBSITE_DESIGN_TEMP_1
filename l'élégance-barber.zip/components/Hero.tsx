import React from 'react';
import { Button } from './UI';

export const Hero: React.FC = () => {
  return (
    <section className="relative h-screen min-h-[600px] flex items-center justify-center overflow-hidden">
      {/* Background with overlay */}
      <div className="absolute inset-0 bg-brand-black">
        {/* Placeholder for where a high-end video would go. Using a high-quality static image for now. */}
        <img 
          src="https://images.unsplash.com/photo-1503951914205-b27cbef86362?q=80&w=2070&auto=format&fit=crop" 
          alt="Barber Shop Interior"
          className="w-full h-full object-cover opacity-40 grayscale"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-brand-black via-transparent to-brand-black/80" />
      </div>

      <div className="relative z-10 container mx-auto px-6 text-center">
        <span className="block text-brand-gold text-sm uppercase tracking-[0.4em] mb-6 animate-fade-in-up">
          Est. 2024
        </span>
        <h1 className="text-5xl md:text-7xl lg:text-8xl font-serif text-brand-light font-thin mb-8 leading-tight tracking-wide">
          The Art of <br/> <span className="italic font-normal">Timeless</span> Grooming
        </h1>
        <p className="max-w-xl mx-auto text-brand-muted text-sm md:text-base leading-relaxed mb-12 font-light">
          Experience the pinnacle of traditional barbering fused with modern luxury. 
          Where precision meets relaxation in an atmosphere of refined elegance.
        </p>
        <div className="flex flex-col md:flex-row gap-6 justify-center">
          <Button onClick={() => document.getElementById('services')?.scrollIntoView({ behavior: 'smooth'})}>
            Explore Services
          </Button>
          <Button variant="outline" onClick={() => document.getElementById('book')?.scrollIntoView({ behavior: 'smooth'})}>
            Book Appointment
          </Button>
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-10 left-1/2 -translate-x-1/2 animate-bounce hidden md:block">
        <div className="w-[1px] h-16 bg-gradient-to-b from-transparent via-brand-gold to-transparent"></div>
      </div>
    </section>
  );
};