import React from 'react';
import { SectionTitle, FadeIn } from './UI';

export const Gallery: React.FC = () => {
  const images = [
    "https://images.unsplash.com/photo-1593702295094-aea22597af65?q=80&w=2070&auto=format&fit=crop",
    "https://images.unsplash.com/photo-1504198322253-cfa87a0ff25f?q=80&w=2070&auto=format&fit=crop",
    "https://images.unsplash.com/photo-1599351431202-6e0c06e76553?q=80&w=2056&auto=format&fit=crop",
    "https://images.unsplash.com/photo-1621605815971-fbc98d665033?q=80&w=2070&auto=format&fit=crop"
  ];

  return (
    <section id="atelier" className="py-24 bg-brand-black">
      <div className="container mx-auto px-6">
        <SectionTitle title="The Atelier" subtitle="Atmosphere" />
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {images.map((src, idx) => (
            <FadeIn key={idx} delay={idx * 150}>
              <div className="aspect-square overflow-hidden group relative cursor-crosshair">
                <img 
                  src={src} 
                  alt="Shop Atmosphere" 
                  className="w-full h-full object-cover grayscale transition-all duration-700 ease-out group-hover:scale-110 group-hover:grayscale-0"
                />
                <div className="absolute inset-0 bg-brand-gold/0 group-hover:bg-brand-gold/10 transition-colors duration-500" />
              </div>
            </FadeIn>
          ))}
        </div>
      </div>
    </section>
  );
};