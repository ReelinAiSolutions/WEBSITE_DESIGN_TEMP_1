import React, { useState } from 'react';
import { SectionTitle, Button, FadeIn } from './UI';
import { ConsultationFormData, ConsultationResponse, ConsultationState } from '../types';
import { getStyleConsultation } from '../services/geminiService';
import { Sparkles, Loader2, Scissors } from 'lucide-react';

export const AiConsultant: React.FC = () => {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState<ConsultationFormData>({
    hairType: 'Straight',
    faceShape: 'Oval',
    stylePreference: 'Classic',
    maintenance: 'Low'
  });
  const [result, setResult] = useState<ConsultationResponse | null>(null);
  const [status, setStatus] = useState<ConsultationState>(ConsultationState.IDLE);

  const handleInputChange = (field: keyof ConsultationFormData, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const generateConsultation = async () => {
    setStatus(ConsultationState.LOADING);
    try {
      const response = await getStyleConsultation(formData);
      setResult(response);
      setStatus(ConsultationState.SUCCESS);
    } catch (e) {
      setStatus(ConsultationState.ERROR);
    }
  };

  return (
    <section id="ai-consultant" className="py-24 bg-brand-black border-y border-brand-gray/30">
      <div className="container mx-auto px-6 max-w-4xl">
        <SectionTitle 
          title="Virtual Style Consultant" 
          subtitle="Powered by AI" 
        />
        
        <div className="bg-brand-dark p-8 md:p-12 border border-brand-gray/50 relative overflow-hidden">
          {/* Decorative background element */}
          <div className="absolute -top-20 -right-20 w-64 h-64 bg-brand-gold/5 rounded-full blur-3xl pointer-events-none" />

          {status === ConsultationState.IDLE && (
            <FadeIn>
              <div className="space-y-8">
                <p className="text-center text-brand-muted font-light mb-8">
                  Unsure which style suits you best? Let our intelligent consultant analyze your profile 
                  and recommend the perfect cut for your features.
                </p>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div className="space-y-2">
                    <label className="text-xs uppercase tracking-widest text-brand-gold">Hair Type</label>
                    <select 
                      className="w-full bg-brand-black border border-brand-gray p-3 text-brand-light focus:border-brand-gold outline-none transition-colors"
                      value={formData.hairType}
                      onChange={(e) => handleInputChange('hairType', e.target.value)}
                    >
                      {['Straight', 'Wavy', 'Curly', 'Coily', 'Thinning'].map(o => <option key={o} value={o}>{o}</option>)}
                    </select>
                  </div>
                  
                  <div className="space-y-2">
                    <label className="text-xs uppercase tracking-widest text-brand-gold">Face Shape</label>
                    <select 
                      className="w-full bg-brand-black border border-brand-gray p-3 text-brand-light focus:border-brand-gold outline-none transition-colors"
                      value={formData.faceShape}
                      onChange={(e) => handleInputChange('faceShape', e.target.value)}
                    >
                      {['Oval', 'Square', 'Round', 'Diamond', 'Heart'].map(o => <option key={o} value={o}>{o}</option>)}
                    </select>
                  </div>

                  <div className="space-y-2">
                    <label className="text-xs uppercase tracking-widest text-brand-gold">Style Preference</label>
                    <select 
                      className="w-full bg-brand-black border border-brand-gray p-3 text-brand-light focus:border-brand-gold outline-none transition-colors"
                      value={formData.stylePreference}
                      onChange={(e) => handleInputChange('stylePreference', e.target.value)}
                    >
                      {['Classic', 'Modern', 'Edgy', 'Professional', 'Low Maintenance'].map(o => <option key={o} value={o}>{o}</option>)}
                    </select>
                  </div>

                  <div className="space-y-2">
                    <label className="text-xs uppercase tracking-widest text-brand-gold">Maintenance Effort</label>
                    <select 
                      className="w-full bg-brand-black border border-brand-gray p-3 text-brand-light focus:border-brand-gold outline-none transition-colors"
                      value={formData.maintenance}
                      onChange={(e) => handleInputChange('maintenance', e.target.value)}
                    >
                      {['Low (Wake & Go)', 'Medium (5 mins)', 'High (Styling required)'].map(o => <option key={o} value={o}>{o}</option>)}
                    </select>
                  </div>
                </div>

                <div className="flex justify-center mt-12">
                  <Button onClick={generateConsultation} className="flex items-center gap-2">
                    <Sparkles size={16} /> Analyze & Recommend
                  </Button>
                </div>
              </div>
            </FadeIn>
          )}

          {status === ConsultationState.LOADING && (
            <div className="flex flex-col items-center justify-center py-12">
              <Loader2 className="animate-spin text-brand-gold mb-4" size={48} />
              <p className="text-brand-light text-lg font-serif animate-pulse">Consulting the archives...</p>
            </div>
          )}

          {status === ConsultationState.SUCCESS && result && (
             <FadeIn>
               <div className="space-y-8">
                  <div className="text-center">
                    <Scissors className="inline-block text-brand-gold mb-4" size={32} />
                    <h3 className="text-2xl font-serif text-brand-light mb-2">The Verdict</h3>
                  </div>
                  
                  <div className="border-l-2 border-brand-gold pl-6 py-2">
                    <h4 className="text-brand-gold text-sm uppercase tracking-widest mb-2">Recommendation</h4>
                    <p className="text-lg text-brand-light font-light leading-relaxed">{result.recommendation}</p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                     <div>
                       <h4 className="text-brand-gold text-sm uppercase tracking-widest mb-4">Styling Tips</h4>
                       <ul className="space-y-3">
                         {result.stylingTips.map((tip, i) => (
                           <li key={i} className="flex items-start gap-2 text-brand-muted font-light text-sm">
                             <span className="mt-1.5 w-1 h-1 bg-brand-gold rounded-full shrink-0" />
                             {tip}
                           </li>
                         ))}
                       </ul>
                     </div>
                     <div>
                        <h4 className="text-brand-gold text-sm uppercase tracking-widest mb-4">Suggested Product</h4>
                        <div className="bg-brand-black p-4 border border-brand-gray">
                          <p className="text-brand-light">{result.suggestedProduct}</p>
                        </div>
                     </div>
                  </div>

                  <div className="flex justify-center pt-8">
                    <Button variant="outline" onClick={() => setStatus(ConsultationState.IDLE)}>
                      Start Over
                    </Button>
                  </div>
               </div>
             </FadeIn>
          )}
          
          {status === ConsultationState.ERROR && (
             <div className="text-center py-12">
               <p className="text-red-400 mb-4">Our stylist is currently unavailable.</p>
               <Button variant="text" onClick={() => setStatus(ConsultationState.IDLE)}>Try Again</Button>
             </div>
          )}
        </div>
      </div>
    </section>
  );
};