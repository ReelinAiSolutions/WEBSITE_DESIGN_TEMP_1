import React from 'react';
import { SERVICES } from '../constants';
import { SectionTitle, FadeIn } from './UI';

export const ServiceSection: React.FC = () => {
  return (
    <section id="services" className="py-24 bg-brand-dark">
      <div className="container mx-auto px-6">
        <SectionTitle title="Our Menu" subtitle="Services" />
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-16 gap-y-12 max-w-5xl mx-auto">
          {SERVICES.map((service, index) => (
            <FadeIn key={service.id} delay={index * 100}>
              <div className="group cursor-default">
                <div className="flex justify-between items-baseline mb-4 border-b border-brand-gray pb-4 group-hover:border-brand-gold transition-colors duration-500">
                  <h3 className="text-xl font-serif text-brand-light group-hover:text-brand-gold transition-colors duration-300">
                    {service.title}
                  </h3>
                  <div className="flex items-center gap-4">
                    <span className="text-xs text-brand-muted uppercase tracking-wider">{service.duration}</span>
                    <span className="text-lg font-serif text-brand-light">{service.price}</span>
                  </div>
                </div>
                <p className="text-sm text-brand-muted leading-relaxed font-light">
                  {service.description}
                </p>
              </div>
            </FadeIn>
          ))}
        </div>
        
        <div className="mt-16 text-center">
          <p className="text-brand-muted text-sm mb-6">Complimentary beverage served with every appointment.</p>
        </div>
      </div>
    </section>
  );
};