import React from 'react';
import { SectionTitle, FadeIn } from './UI';

export const AboutSection: React.FC = () => {
  return (
    <section id="heritage" className="py-24 md:py-32 bg-brand-black relative">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-16 items-center">
          {/* Text Content */}
          <div>
            <FadeIn>
              <SectionTitle 
                title="A Legacy of Excellence" 
                subtitle="Heritage" 
                centered={false} 
              />
              <p className="text-brand-muted leading-8 mb-6 font-light">
                Founded on the principles of old-world craftsmanship and contemporary style, 
                L'Élégance was created for the discerning gentleman who refuses to compromise. 
              </p>
              <p className="text-brand-muted leading-8 mb-8 font-light">
                We believe that a haircut is not just a service, but a ritual. Our master barbers 
                blend traditional techniques with modern precision to create a look that is 
                uniquely yours. Every detail, from our hand-stitched leather chairs to our 
                curated selection of grooming products, is designed to provide an unparalleled experience.
              </p>
              
              <div className="grid grid-cols-2 gap-8 mt-12 border-t border-brand-gray pt-8">
                <div>
                   <span className="block text-3xl font-serif text-brand-gold mb-2">2.5k+</span>
                   <span className="text-xs uppercase tracking-widest text-brand-muted">Happy Clients</span>
                </div>
                <div>
                   <span className="block text-3xl font-serif text-brand-gold mb-2">15+</span>
                   <span className="text-xs uppercase tracking-widest text-brand-muted">Awards Won</span>
                </div>
              </div>
            </FadeIn>
          </div>

          {/* Image Composition */}
          <div className="relative">
            <FadeIn delay={200}>
              <div className="relative z-10 aspect-[3/4] overflow-hidden">
                <img 
                  src="https://images.unsplash.com/photo-1585747860715-2ba37e788b70?q=80&w=2074&auto=format&fit=crop" 
                  alt="Barber working" 
                  className="w-full h-full object-cover grayscale hover:grayscale-0 transition-all duration-700 ease-in-out"
                />
              </div>
              {/* Decorative Frame */}
              <div className="absolute top-10 -right-10 w-full h-full border border-brand-gold/30 z-0 hidden md:block" />
            </FadeIn>
          </div>
        </div>
      </div>
    </section>
  );
};