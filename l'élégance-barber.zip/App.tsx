import React from 'react';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { AboutSection } from './components/AboutSection';
import { ServiceSection } from './components/ServiceSection';
import { AiConsultant } from './components/AiConsultant';
import { Gallery } from './components/Gallery';
import { BookingCta } from './components/BookingCta';
import { Footer } from './components/Footer';

function App() {
  return (
    <div className="min-h-screen bg-brand-black text-brand-light font-sans selection:bg-brand-gold selection:text-brand-black">
      <Header />
      <main>
        <Hero />
        <AboutSection />
        <ServiceSection />
        <Gallery />
        <AiConsultant />
        <BookingCta />
      </main>
      <Footer />
    </div>
  );
}

export default App;